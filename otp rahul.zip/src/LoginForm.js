
import "./style.css";
import React, { useState } from "react";

const LoginForm = ({ isShowLogin }) => {
  const [otp, setOtp] = useState(new Array(6).fill(""));

  const handleChange = (element, index) => {
      if (isNaN(element.value)) return false;

      setOtp([...otp.map((d, idx) => (idx === index ? element.value : d))]);

      //Focus next input
      if (element.nextSibling) {
          element.nextSibling.focus();
      }
  };
  return (
    <div className={`${isShowLogin ? "active" : ""} show`}>
      <div className="login-form">
      <div className="row">
                <div className="col text-center">
                    <h2>Phone Verification</h2>
                    <p>Enter the OTP you received on 9670XXXX35</p>

                    {otp.map((data, index) => {
                        return (
                            <input
                                className="r"
                                type="text"
                                name="otp"
                                maxLength="1"
                                key={index}
                                value={data}
                                onChange={e => handleChange(e.target, index)}
                                onFocus={e => e.target.select()}
                            />
                        );
                    })}
                    

                    <p>OTP Entered - {otp.join("")}</p>
                    
                   
                        <div className="ro">
                          <div className="col">
                          <button
                            className=" btn-secondary mr-2"
                            onClick={e => setOtp([...otp.map(v => "")])}
                        >
                           Change Number
                        </button>
                            </div>
                            <div className="col">
                            <button
                            className=" btn-secondary mr-2"
                            onClick={e => setOtp([...otp.map(v => "")])}
                        >
                      Re-Send OTP
                        </button>
                            </div>
                          </div>
                      {/* <div className='col-md-6'>
                      <button
                            className=" btn-secondary mr-2"
                            onClick={e => setOtp([...otp.map(v => "")])}
                        >
                      Re-Send OTP
                        </button>
                      </div> */}
                  
                      </div><p>
                       
                        <button
                            className="btn btn-primary"
                            onClick={e =>
                                alert("Entered OTP is " + otp.join(""))
                            }
                        >
                            Verify Phone Number
                        </button>
                    </p>
                </div>
            </div>
      </div>
  
  );
};

export default LoginForm;
